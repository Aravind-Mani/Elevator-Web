package com.demo.elevator.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Elevator {
	
	public Elevator(){
		
	}
	
	public Elevator(String elevatorId, int currentFloor) {
		super();
		this.elevatorId = elevatorId;
		this.currentFloor = currentFloor;
	}

	
	private String elevatorId;
	
	private int currentFloor;
	
	public String getElevatorId() {
		return elevatorId;
	}
	public void setElevatorId(String elevatorId) {
		this.elevatorId = elevatorId;
	}
	public int getCurrentFloor() {
		return currentFloor;
	}
	public void setCurrentFloor(int currentFloor) {
		this.currentFloor = currentFloor;
	}
	
	

}
