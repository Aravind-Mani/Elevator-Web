package com.demo.elevator.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.demo.elevator.model.Elevator;

public class ElevatorManagerImpl implements ElevatorManager {
	
	private HashMap<String, Elevator> elevatorDetails;
	
	public HashMap<String, Elevator> getElevatorDetails() {
		if(elevatorDetails!=null){
			return elevatorDetails;
		}
		elevatorDetails =  new HashMap<String, Elevator>();
		return elevatorDetails;
	}

	public void setElevatorDetails(HashMap<String, Elevator> elevatorDetails) {
		this.elevatorDetails = elevatorDetails;
	}

	@Override
	public List<Elevator> getAllElevatorDetails() {
		ArrayList<Elevator> elevators = new ArrayList<Elevator>();
		Collection<Elevator> elevatorCol = getElevatorDetails().values();
		if(!CollectionUtils.isEmpty(elevatorCol))
		{
			for (Elevator elevator : getElevatorDetails().values()) {
				elevators.add(elevator);
			}
		}
		return elevators;
	}

	@Override
	public void elevatorPress(Elevator elevator) {
		getElevatorDetails().put(elevator.getElevatorId(), elevator);
	}
	
	@Override
	public Elevator elevatorPressUpdate(Elevator elevator) {
		if(elevator.getElevatorId()!=null)
		{
			getElevatorDetails().put(elevator.getElevatorId(), elevator);
		}
		return getElevatorDetails().get(elevator.getElevatorId());
			
	}
	
	public Elevator getElevatorById(String elevatorId) {
		return getElevatorDetails().get(elevatorId);
	}

	@Override
	public void elevatorClearAll() {
		elevatorDetails = null;
		
	}

	@Override
	public Elevator updateElevator(Elevator elevator) {
		getElevatorDetails().put(elevator.getElevatorId(), elevator);
		return null;
	}

	@Override
	public void deleteElevatorById(String elevatorId) {
		getElevatorDetails().remove(elevatorId);
	}
	
	
	


}
