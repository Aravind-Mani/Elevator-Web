package com.demo.elevator.manager;

import java.util.HashMap;

import com.demo.elevator.model.Elevator;

public class ElevatorMap {
	
	private static ElevatorMap elevatorMap;
	private HashMap<String, Elevator> elevatorDetails = new HashMap<>();
	
	private ElevatorMap(){
		
	}
	
	public static ElevatorMap getElevatorMapInstance(){
		if(elevatorMap!=null){
			return elevatorMap;
		}else{
			return new ElevatorMap();
		}
	}
	
	public HashMap<String, Elevator> getElevatorDetails(){
		return elevatorDetails;
	}
	
	public void setElevatorDetails(HashMap<String, Elevator> elevatorDetails){
		this.elevatorDetails = elevatorDetails;
	}

}
