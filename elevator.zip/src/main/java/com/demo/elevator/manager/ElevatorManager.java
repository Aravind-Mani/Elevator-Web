package com.demo.elevator.manager;

import java.util.List;

import com.demo.elevator.model.Elevator;

public interface ElevatorManager {
	
	
	public List<Elevator> getAllElevatorDetails();
	
	public void elevatorPress(Elevator elevator);
	
	public Elevator elevatorPressUpdate(Elevator elevator);
	
	public void elevatorClearAll();
	
	public Elevator getElevatorById(String elevatorId);
	
	public Elevator updateElevator(Elevator elevator);
	
	public void deleteElevatorById(String elevatorId);

}
