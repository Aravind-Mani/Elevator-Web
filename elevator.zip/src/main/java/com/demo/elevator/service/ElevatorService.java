package com.demo.elevator.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.demo.elevator.manager.ElevatorManager;
import com.demo.elevator.model.Elevator;

@Component
@Path("/elevators")
public class ElevatorService {
	
	
	@Autowired
	ElevatorManager elevatorManager;
	
	@GET
	@Produces(value={MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public List<Elevator> getAllElevatorDetails(){
		return elevatorManager.getAllElevatorDetails();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void elevatorPress(Elevator elevator){
		elevatorManager.elevatorPress(elevator);
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public void elevatorPressUpdate(Elevator elevator){
		elevatorManager.elevatorPressUpdate(elevator);
	}
	
	@DELETE
	public void elevatorClearAll(){
		elevatorManager.elevatorClearAll();
	}
	
	@GET
	@Path("/{elevatorId}")
	@Produces(value={MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Elevator getElevatorById(@PathParam ("elevatorId") String elevatorId){
		return elevatorManager.getElevatorById(elevatorId);
	}
	
	@PUT
	@Path("/{elevatorId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(value={MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Elevator updateElevatorById(Elevator elevator){
		return elevatorManager.updateElevator(elevator);
	}
	
	@DELETE
	@Path("/{elevatorId}")
	public void deleteElevatorById(@PathParam ("elevatorId") String elevatorId){
		elevatorManager.deleteElevatorById(elevatorId);
	}
	
	
	

}
