var chart = AmCharts.makeChart("chartdiv",
{
    "type": "serial",
	"theme": "light",
    "dataProvider": [{
        "name": "John",
        "points": 35654,
        "color": "#7F8DA9",
        "bullet": "//www.amcharts.com/lib/3/images/0.gif"
    }, {
        "name": "Damon",
        "points": 65456,
        "color": "#FEC514",
        "bullet": "//www.amcharts.com/lib/3/images/1.gif"
    }, {
        "name": "Patrick",
        "points": 45724,
        "color": "#DB4C3C",
        "bullet": "//www.amcharts.com/lib/3/images/2.gif"
    }, {
        "name": "Mark",
        "points": 13654,
        "color": "#DAF0FD",
        "bullet": "//www.amcharts.com//lib/3/images/3.gif"
    }],
    "valueAxes": [{
        "maximum": 80000,
        "minimum": 0,
        "axisAlpha": 0,
        "dashLength": 4,
        "position": "left"
    }],
    "startDuration": 1,
    "graphs": [{
        "balloonText": "<span style='font-size:13px;'>[[category]]: <b>[[value]]</b></span>",
        "bulletOffset": 16,
        "bulletSize": 34,
        "colorField": "color",
        "cornerRadiusTop": 8,
        "customBulletField": "bullet",
        "fillAlphas": 0.8,
        "lineAlpha": 0,
        "type": "column",
        "valueField": "points"
    }],
    "marginTop": 0,
    "marginRight": 0,
    "marginLeft": 0,
    "marginBottom": 0,
    "autoMargins": false,
    "categoryField": "name",
    "categoryAxis": {
        "axisAlpha": 0,
        "gridAlpha": 0,
        "inside": true,
        "tickLength": 0
    },
    "export": {
    	"enabled": true
     }
});


var chart1 = AmCharts.makeChart("stackedbardiv", {
	  "type": "serial",
	  "theme": "light",
	  "rotate": true,
	  "marginBottom": 50,
	  "dataProvider": [{
	    "age": "85+",
	    "male": -0.1,
	    "female": 0.3
	  }, {
	    "age": "80-54",
	    "male": -0.2,
	    "female": 0.3
	  }, {
	    "age": "75-79",
	    "male": -0.3,
	    "female": 0.6
	  }, {
	    "age": "70-74",
	    "male": -0.5,
	    "female": 0.8
	  }, {
	    "age": "65-69",
	    "male": -0.8,
	    "female": 1.0
	  }, {
	    "age": "60-64",
	    "male": -1.1,
	    "female": 1.3
	  }, {
	    "age": "55-59",
	    "male": -1.7,
	    "female": 1.9
	  }, {
	    "age": "50-54",
	    "male": -2.2,
	    "female": 2.5
	  }, {
	    "age": "45-49",
	    "male": -2.8,
	    "female": 3.0
	  }, {
	    "age": "40-44",
	    "male": -3.4,
	    "female": 3.6
	  }, {
	    "age": "35-39",
	    "male": -4.2,
	    "female": 4.1
	  }, {
	    "age": "30-34",
	    "male": -5.2,
	    "female": 4.8
	  }, {
	    "age": "25-29",
	    "male": -5.6,
	    "female": 5.1
	  }, {
	    "age": "20-24",
	    "male": -5.1,
	    "female": 5.1
	  }, {
	    "age": "15-19",
	    "male": -3.8,
	    "female": 3.8
	  }, {
	    "age": "10-14",
	    "male": -3.2,
	    "female": 3.4
	  }, {
	    "age": "5-9",
	    "male": -4.4,
	    "female": 4.1
	  }, {
	    "age": "0-4",
	    "male": -5.0,
	    "female": 4.8
	  }],
	  "startDuration": 1,
	  "graphs": [{
	    "fillAlphas": 0.8,
	    "lineAlpha": 0.2,
	    "type": "column",
	    "valueField": "male",
	    "title": "Lift 1",
	    "labelText": "[[value]]",
	    "clustered": false,
	    "labelFunction": function(item) {
	      return Math.abs(item.values.value);
	    },
	    "balloonFunction": function(item) {
	      return item.category + ": " + Math.abs(item.values.value) + "%";
	    }
	  }, {
	    "fillAlphas": 0.8,
	    "lineAlpha": 0.2,
	    "type": "column",
	    "valueField": "female",
	    "title": "Lift 2",
	    "labelText": "[[value]]",
	    "clustered": false,
	    "labelFunction": function(item) {
	      return Math.abs(item.values.value);
	    },
	    "balloonFunction": function(item) {
	      return item.category + ": " + Math.abs(item.values.value) + "%";
	    }
	  }],
	  "categoryField": "age",
	  "categoryAxis": {
	    "gridPosition": "start",
	    "gridAlpha": 0.2,
	    "axisAlpha": 0
	  },
	  "valueAxes": [{
	    "gridAlpha": 0,
	    "ignoreAxisWidth": true,
	    "labelFunction": function(value) {
	      return Math.abs(value) + '%';
	    },
	    "guides": [{
	      "value": 0,
	      "lineAlpha": 0.2
	    }]
	  }],
	  "balloon": {
	    "fixedPosition": true
	  },
	  "chartCursor": {
	    "valueBalloonsEnabled": false,
	    "cursorAlpha": 0.05,
	    "fullWidth": true
	  },
	  "allLabels": [{
	    "text": "Lift 1",
	    "x": "28%",
	    "y": "97%",
	    "bold": true,
	    "align": "middle"
	  }, {
	    "text": "Lift 2",
	    "x": "75%",
	    "y": "97%",
	    "bold": true,
	    "align": "middle"
	  }],
	 "export": {
	    "enabled": true
	  }   

	});

var chart2 = AmCharts.makeChart( "piechart", {
	  "type": "pie",
	  "theme": "light",
	  "dataProvider": [ {
	    "country": "Floor 6",
	    "value": 760
	  }, {
	    "country": "Floor 5",
	    "value": 840
	  }, {
	    "country": "Floor 4",
	    "value": 650
	  }, {
	    "country": "Floor 3",
	    "value": 579
	  }, {
	    "country": "Floor 2",
	    "value": 824
	  }, {
	    "country": "Floor 1",
	    "value": 950
	  } ],
	  "valueField": "value",
	  "titleField": "country",
	  "outlineAlpha": 0.4,
	  "depth3D": 15,
	  "balloonText": "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>",
	  "angle": 30,
	  "export": {
	    "enabled": true
	  }
	} );
	jQuery( '.chart-input' ).off().on( 'input change', function() {
	  var property = jQuery( this ).data( 'property' );
	  var target = chart;
	  var value = Number( this.value );
	  chart.startDuration = 0;

	  if ( property == 'innerRadius' ) {
	    value += "%";
	  }

	  target[ property ] = value;
	  chart.validateNow();
	} );
	
	// generate data
	var chartData = [];

	function generateChartData() {
	    var firstDate = new Date();
	    firstDate.setTime(firstDate.getTime() - 10 * 24 * 60 * 60 * 1000);

	    for (var i = firstDate.getTime(); i < (firstDate.getTime() + 10 * 24 * 60 * 60 * 1000); i += 60 * 60 * 1000) {
	        var newDate = new Date(i);

	        if (i == firstDate.getTime()) {
	            var value1 = Math.round(Math.random() * 10) + 1;
	        } else {
	            var value1 = Math.round(chartData[chartData.length - 1].value1 / 100 * (90 + Math.round(Math.random() * 20)) * 100) / 100;
	        }

	        if (newDate.getHours() == 12) {
	            // we set daily data on 12th hour only
	            var value2 = Math.round(Math.random() * 12) + 1;
	            chartData.push({
	                date: newDate,
	                value1: value1,
	                value2: value2
	            });
	        } else {
	            chartData.push({
	                date: newDate,
	                value1: value1
	            });
	        }
	    }
	}

	generateChartData();

	var chart5 = AmCharts.makeChart("hourchart", {
	    "type": "serial",
	    "theme": "light",
	    "marginRight": 80,
	    "dataProvider": chartData,
	    "valueAxes": [{
	        "axisAlpha": 0.1
	    }],

	    "graphs": [{
	        "balloonText": "[[title]]: [[value]]",
	        "columnWidth": 20,
	        "fillAlphas": 1,
	        "title": "daily",
	        "type": "column",
	        "valueField": "value2"
	    }, {
	        "balloonText": "[[title]]: [[value]]",
	        "lineThickness": 2,
	        "title": "intra-day",
	        "valueField": "value1"
	    }],
	    "zoomOutButtonRollOverAlpha": 0.15,
	    "chartCursor": {
	        "categoryBalloonDateFormat": "MMM DD JJ:NN",
	        "cursorPosition": "mouse",
	        "showNextAvailable": true
	    },
	    "autoMarginOffset": 5,
	    "columnWidth": 1,
	    "categoryField": "date",
	    "categoryAxis": {
	        "minPeriod": "hh",
	        "parseDates": true
	    },
	    "export": {
	        "enabled": true
	    }
	});