var elevatorApp = angular.module("elevatorApp",[]);

elevatorApp.controller("mainController", function($scope, $http){
	$http({
        method : 'GET',
        url : 'http://localhost:8080/elevator/webapi/elevators'
    }).success(
        function(data, status, headers, config) {
            if(data !== null)
            {
            	if(data.elevator[0])
            	{
            		$scope.elevatorId0 = data.elevator[0].elevatorId;
            		$scope.currentFloor0 = data.elevator[0].currentFloor;
            		$scope.elevatorStatus0 = 'The elevator is moving to floor ' + $scope.currentFloor0;
            	}
            	else
            	{
            		$scope.elevatorId0 = data.elevator.elevatorId;
            		$scope.currentFloor0 = data.elevator.currentFloor;
            		$scope.elevatorStatus0 = 'The elevator is moving to floor ' + $scope.currentFloor0;
            	}
            	
            	if(data.elevator[1])
            	{
            		$scope.elevatorId1 = data.elevator[1].elevatorId;
            		$scope.currentFloor1 = data.elevator[1].currentFloor;
            		$scope.elevatorStatus1 = 'The elevator is moving to floor ' + $scope.currentFloor1;
            	}
            	
            }
           
            //$scope.liftId = data.elevator[0].elevatorId;
        }).error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
        });
});