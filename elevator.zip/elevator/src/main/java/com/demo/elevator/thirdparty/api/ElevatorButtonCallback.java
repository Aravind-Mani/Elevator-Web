package com.demo.elevator.thirdparty.api;

public interface ElevatorButtonCallback {
	public void buttonPressed(ElevatorButton button);
	
	public void movingElevatorToFloor(int floor);
}
