package com.demo.elevator.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.demo.elevator.manager.ElevatorManager;
import com.demo.elevator.model.Elevator;

@Component
@Path("/elevators")
public class ElevatorService {
	
	
	@Autowired
	ElevatorManager elevatorManager;
	
	@GET
	@Produces(value={MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public List<Elevator> getAllElevatorDetails(){
		return elevatorManager.getAllElevatorDetails();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void elevatorPress(Elevator elevator){
		elevatorManager.elevatorPress(elevator);
	}
	
	@GET
	@Path("/{elevatorId}")
	@Produces(value={MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Elevator getElevatorById(@PathParam ("elevatorId") String elevatorId){
		return elevatorManager.getElevatorById(elevatorId);
	}
	
	
	

}
