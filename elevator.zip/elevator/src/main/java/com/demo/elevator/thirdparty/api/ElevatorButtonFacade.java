package com.demo.elevator.thirdparty.api;

public interface ElevatorButtonFacade {
	public void pressButton(ElevatorButton button);
}
